
Read me
-------
More png icon at: http://fa2png.io/