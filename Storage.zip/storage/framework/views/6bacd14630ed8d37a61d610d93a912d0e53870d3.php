<?php if(!(isset($paddingTopExists) and $paddingTopExists)): ?>
	<div class="h-spacer"></div>
<?php endif; ?><?php /**PATH /home/developer/public_html/resources/views/common/spacer.blade.php ENDPATH**/ ?>