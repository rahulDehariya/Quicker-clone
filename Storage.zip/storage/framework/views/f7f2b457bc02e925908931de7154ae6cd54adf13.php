<?php echo e($slot); ?>

<?php /**PATH /home/developer/public_html/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>