<!-- expand/minimize button column -->
<td class="details-control text-center cursor-pointer">
	<i class="far fa-plus-square details-row-button cursor-pointer" data-entry-id="<?php echo e($entry->getKey()); ?>"></i>
</td><?php /**PATH /home/developer/public_html/resources/views/vendor/admin/panel/columns/details_row_button.blade.php ENDPATH**/ ?>