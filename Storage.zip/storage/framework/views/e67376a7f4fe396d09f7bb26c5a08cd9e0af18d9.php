
<td>
	<?php
	    echo $entry->{$column['function_name']}();
    ?>
</td><?php /**PATH /home/developer/public_html/resources/views/vendor/admin/panel/columns/model_function.blade.php ENDPATH**/ ?>