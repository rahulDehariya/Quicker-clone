<?php

namespace Larapen\Admin\PanelTraits\Filters;

class FiltersCollection extends \Illuminate\Support\Collection
{
	public function removeFilter($name)
	{
	}
	
	/*
	public function count()
	{
		dd($this);
	}
	*/
}
