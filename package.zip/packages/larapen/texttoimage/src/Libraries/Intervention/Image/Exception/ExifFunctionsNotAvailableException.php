<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ExifFunctionsNotAvailableException extends \RuntimeException
{
    # nothing to override
}
