<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ImageQualityException extends \RuntimeException
{
    # nothing to override
}
