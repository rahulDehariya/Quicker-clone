<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class NotReadableException extends \RuntimeException
{
    # nothing to override
}
