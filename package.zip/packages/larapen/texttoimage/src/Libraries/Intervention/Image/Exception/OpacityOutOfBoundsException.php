<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class OpacityOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
