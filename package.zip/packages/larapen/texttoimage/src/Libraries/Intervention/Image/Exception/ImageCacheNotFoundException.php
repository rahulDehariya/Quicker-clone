<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ImageCacheNotFoundException extends \RuntimeException
{
    # nothing to override
}
