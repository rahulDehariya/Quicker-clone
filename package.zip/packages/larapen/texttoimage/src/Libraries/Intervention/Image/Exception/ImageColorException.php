<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ImageColorException extends \RuntimeException
{
    # nothing to override
}
