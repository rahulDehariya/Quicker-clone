<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ImageNotFoundException extends \RuntimeException
{
    # nothing to override
}
