<?php namespace Larapen\LaravelLocalization\Exceptions;

use Exception;

class UnsupportedLocaleException extends Exception {

}
