<?php
/**
 * LaraClassified - Classified Ads Web Application
 * Copyright (c) BedigitCom. All Rights Reserved
 *
 * Website: http://www.bedigit.com
 *
 * LICENSE
 * -------
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the inclusion
 * of the above copyright notice. If you Purchased from Codecanyon,
 * Please read the full License from here - http://codecanyon.net/licenses/standard
 */

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

abstract class RequestPost extends FormRequest
{
	/**
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize()
	{
		return true;
	}
	
	/**
	 * Handle a failed validation attempt.
	 *
	 * @param Validator $validator
	 * @throws ValidationException
	 */
	protected function failedValidation(Validator $validator)
	{
		if ($this->ajax() || $this->wantsJson() || $this->segment(1) == 'api') {
			// Get Errors
			$errors = (new ValidationException($validator))->errors();
			
			// Get Json
			$json = [
				'status' => 404,
				'message' => t('An error occurred while validating the data'),
				'error'    => $errors,
			];
			
			// Add a specific json attributes for 'bootstrap-fileinput' plugin
			if (Str::contains(get_called_class(), 'PhotoRequest')) {
				// Get errors in text
				$errorsTxt = t('Error found');
				if (is_array($errors) && count($errors) > 0) {
					foreach ($errors as $value) {
						if (is_array($value)) {
							foreach ($value as $v) {
								$errorsTxt .= '<br>- ' . $v;
							}
						} else {
							$errorsTxt .= '<br>- ' . $value;
						}
					}
				}
				
				// NOTE: 'bootstrap-fileinput' need 'errorkeys' (array) element & 'error' (text) element
				$json['error'] = $errorsTxt;
				$json['errorkeys'] = $errors;
			}
			
			throw new HttpResponseException(response()->json($json, JsonResponse::HTTP_UNPROCESSABLE_ENTITY));
		}
		
		parent::failedValidation($validator);
	}
	
	/**
	 * reCAPTCHA Rules
	 *
	 * @param array $rules
	 * @return array
	 */
	protected function recaptchaRules($rules = [])
	{
		// reCAPTCHA
		if (
			config('settings.security.recaptcha_activation')
			&& config('recaptcha.site_key')
			&& config('recaptcha.secret_key')
		) {
			$rules['g-recaptcha-response'] = ['recaptcha'];
		}
		
		return $rules;
	}
}
