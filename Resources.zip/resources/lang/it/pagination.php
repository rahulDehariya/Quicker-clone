<?php 

return [
    'previous' => '« Precedente',
    'next' => 'Successivo »',
];
