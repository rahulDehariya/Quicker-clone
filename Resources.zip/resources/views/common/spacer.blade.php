@if (!(isset($paddingTopExists) and $paddingTopExists))
	<div class="h-spacer"></div>
@endif