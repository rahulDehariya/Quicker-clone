<?php return array(
    'IN' => 'ਭਾਰਤ',
);
