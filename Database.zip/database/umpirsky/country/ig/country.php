<?php return array(
    'BM' => 'Bemuda',
    'BJ' => 'Binin',
    'CN' => 'Chaina',
    'KM' => 'Comorosu',
    'HT' => 'Hati',
    'LY' => 'Libyia',
    'MV' => 'Maldivesa',
    'NG' => 'Nigeria',
);
