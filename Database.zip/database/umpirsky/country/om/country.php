<?php return array(
    'BR' => 'Brazil',
    'FR' => 'France',
    'DE' => 'Germany',
    'IN' => 'India',
    'IT' => 'Italy',
    'ET' => 'Itoophiyaa',
    'JP' => 'Japan',
    'KE' => 'Keeniyaa',
    'RU' => 'Russia',
    'UK' => 'United Kingdom',
    'US' => 'United States',
    'CN' => 'China',
);
