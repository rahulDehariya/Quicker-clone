<?php return array(
    'GL' => 'Kalaallit Nunaat',
);
