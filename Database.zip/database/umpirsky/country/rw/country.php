<?php return array(
    'TO' => 'Igitonga',
    'RW' => 'Rwanda',
);
